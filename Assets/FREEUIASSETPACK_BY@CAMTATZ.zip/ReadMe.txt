//////////////////////////////
PLATFORMER ASSET PACK #4
By Cam Tatz  @CamTatz
/////////////////////////////


Thank you for downloading!

You make use this pack for any project: Personal or Commercial.
I am not responsible for how you use the contents of this Asset Pack.


If you have any questions you can contact me on twitter: @CamTatz


Please show me any work you have created with this pack and I'll be happy to share it!
Keep on makin' art.

Cam

// This work is licensed PUBLIC DOMAIN //